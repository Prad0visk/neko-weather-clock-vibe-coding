This repository contains a minimal encoder adapted from `tools/theme_pack.py` in `giovi321/smalltv-mod` (https://github.com/giovi321/smalltv-mod).

The upstream repository provides the following license for its code:

DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE, Version 2, December 2004
Copyright (C) 2026 giovi321

Everyone is permitted to copy and distribute verbatim or modified copies of this license document, and changing it is allowed as long as the name is changed.

TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

0. You just DO WHAT THE FUCK YOU WANT TO.
